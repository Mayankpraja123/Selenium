package Day34_Date_picker_Calender;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DatePicker {
	
	static void SelectFutureDates(WebDriver driver, String month, String year,String date) {
	//SELECT month and year;
		
		while(true)
		{
		String currentMonth =  driver.findElement(By.xpath("//span[@class='ui-datepicker-month']")).getText();
		String currentYear  =  driver.findElement(By.xpath("//span[@class='ui-datepicker-year']")).getText();
		
		System.out.println("currentMonth::"+ currentMonth);
		System.out.println("currentYear::"+ currentYear);
		
		if(currentMonth.equals(month) && currentYear.equals(year))
		{
			break;
		}
		
		//span[@class='ui-icon ui-icon-circle-triangle-w']
		//driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-w']")).click();
		driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-e']")).click(); 
		
	}
		
		List<WebElement>  allDates =   driver.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//tbody//tr/td//a"));
		
		for(WebElement dates : allDates)
		{
			if(dates.getText().equals(date)) {
				dates.click();
				break;
			}
		
	}
	}
	
	static void SelectPastDates(WebDriver driver, String month, String year,String date) {
	//SELECT month and year;
		
		while(true)
		{
		String currentMonth =  driver.findElement(By.xpath("//span[@class='ui-datepicker-month']")).getText();
		String currentYear  =  driver.findElement(By.xpath("//span[@class='ui-datepicker-year']")).getText();
		
		System.out.println("currentMonth::"+ currentMonth);
		System.out.println("currentYear::"+ currentYear);
		
		if(currentMonth.equals(month) && currentYear.equals(year))
		{
			break;
		}
		
		//span[@class='ui-icon ui-icon-circle-triangle-w']
		driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-w']")).click();
		//driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-e']")).click(); 
		
	}
		
		List<WebElement>  allDates =   driver.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//tbody//tr/td//a"));
		
		for(WebElement dates : allDates)
		{
			if(dates.getText().equals(date)) {
				dates.click();
				break;
			}
		
	}
	}
	
	
	public static void main(String[] args) { 
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://jqueryui.com/datepicker/");
		driver.switchTo().frame(0);
		
		//Method1 switch to Using sendKey direct dtae
		//driver.findElement(By.xpath("//input[@id='datepicker']")).sendKeys("04/05/2024");
		
		
		//Method 2 using date picker
		String year = "2025";
		String month = "May";
		String date = "20";
		driver.findElement(By.xpath("//input[@id='datepicker']")).click();
		SelectFutureDates(driver, month,year,date);
		SelectPastDates(driver, month,year,date);
		
	}

	}
