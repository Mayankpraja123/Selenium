package Day34_Date_picker_Calender;

import java.time.Month;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DatePickerDemo {
	// user defined function for converting from string -->Month;
	
	static void selectDate(WebDriver driver, String requireYear,String requireMonth,String requireDate) {
		  WebElement yearDropDown = driver.findElement(By.xpath("//select[@class='ui-datepicker-year']"));
		    Select selectYear = new Select(yearDropDown);
		    selectYear.selectByVisibleText(requireYear);
		    
		    //select month
		    
		    while(true) {
		    	String displayMonth =  driver.findElement(By.xpath("//span[@class='ui-datepicker-month']")).getText();
		 	    Month expectedMonth =  convertMonth(requireMonth);
		 	    Month currentMonth = convertMonth(displayMonth);
		 	    //convert requiredMonth and DisplayMonth in to Month Object
		 	    
		 	   int result =  expectedMonth.compareTo(currentMonth);
		 	   // 0  equal , 1 future month  , -1 past month
		 	   
		 	   if(result < 0)
		 	   {
		 		  driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-w']")).click();
		 			
		 	   }
		 	   else if(result > 0)
		 	   {
		 		  driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-e']")).click(); 
		 	   }
		 	   else {
		 		   break;
		 	   }
		    }
		    
		    //date
		    List<WebElement>  allDates =   driver.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//tbody//tr//td//a"));
		    
		    for(WebElement dt : allDates)
		    {
		    	if(dt.getText().equals(requireDate))
		    	{
		    		dt.click();
		    		break;
		    	}
		    }
	}
	
	static Month convertMonth(String month) {
		HashMap<String,Month> monthMap = new HashMap<String,Month>();
		monthMap.put("January", Month.JANUARY);
		monthMap.put("February", Month.FEBRUARY);
		monthMap.put("March", Month.MARCH);
		monthMap.put("April", Month.APRIL);
		monthMap.put("May", Month.MAY);
		monthMap.put("June", Month.JUNE);
		monthMap.put("July", Month.JULY);
		monthMap.put("August", Month.AUGUST);
		monthMap.put("September", Month.SEPTEMBER);
		monthMap.put("October", Month.OCTOBER);
		monthMap.put("November", Month.NOVEMBER);
		monthMap.put("December", Month.DECEMBER);
		
		Month vmonth = monthMap.get(month);
		
		if(vmonth== null) {
			System.out.println("Invalid Month");
		}
		
		return vmonth;
	}
	
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://testautomationpractice.blogspot.com/");
		String requireYear = "2022";
		String requireMonth = "June";
		String requireDate = "15";
		driver.switchTo().frame("frame-one796456169");
		driver.findElement(By.xpath("//span[@class='icon_calendar']")).click();
		
	    //span[@class='ui-datepicker-month']
	    // year dropdown//select[@class='ui-datepicker-year']
		selectDate(driver,requireYear,requireMonth,requireDate);
		
		
		
		
	}
}
