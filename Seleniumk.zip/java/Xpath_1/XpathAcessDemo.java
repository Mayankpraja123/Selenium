package Xpath_1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class XpathAcessDemo {
	
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://money.rediff.com/gainers/bse/daily/groupa");
		driver.manage().window().maximize();
		
		//self Selector the current date;
		String text = driver.findElement(By.xpath("//a[contains(text(),'Metro Brands')]/self::a")).getText();
		System.out.println("Self ::: "+ text); // Zomato
		
		// Parent -selects the parent of the current node (always One)
		String text1 = driver.findElement(By.xpath("//a[contains(text(),'Metro Brands')]/parent::td")).getText();// there
		System.out.println("Parent ::: "+ text1); // Zomato
		
		// child - Selects all the children of the current node (One or any);
		List<WebElement> child = driver.findElements(By.xpath("//a[contains(text(),'Metro Brands')]/ancestor::tr"));//
		System.out.println("number of the child element ::: "+ child.size()); // 5
		
		// Desendant - Selects all the descentdants (children, grandchildren, etc.) of the current node.
		List<WebElement> desendenants = driver.findElements(By.xpath("//a[contains(text(),'Metro Brands')]/ancestor::tr"));//
		System.out.println("desendenants of the desendenants element ::: "+ desendenants.size()); // 5
				
		// Following - Selects  everything in the doucment after the closing tag of the current node;
		List<WebElement> followingnodes = driver.findElements(By.xpath("//a[contains(text(),'Metro Brands')]/ancestor::tr"));//
		System.out.println("number of the followingnodes element ::: "+ followingnodes.size()); // 5
				
		// Preceding - Selects all the nodes that appears before the current node in the doucment
		List<WebElement> preceding = driver.findElements(By.xpath("//a[contains(text(),'Metro Brands')]/ancestor::tr"));//
		System.out.println("number of the preceding element ::: "+ preceding.size()); // 5
				
		// Following -sibling Select all the sibling after the current nodes.
		List<WebElement> follwingsSibling = driver.findElements(By.xpath("//a[contains(text(),'Metro Brands')]/ancestor::tr"));//
		System.out.println("number of the follwingsSibling element ::: "+ follwingsSibling.size()); // 5
		
		
		// Preceding -sibling Select all the sibling before the current nodes.
		List<WebElement> precendingSibling = driver.findElements(By.xpath("//a[contains(text(),'Metro Brands')]/ancestor::tr"));//
		System.out.println("number of the precending element ::: "+ precendingSibling.size()); // 5
		
		
	
	}

}
