package Xpath;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class XpathDemo {
	
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.get("https://demo.opencart.com/");
		//driver.get("https://demo.nopcommerce.com/");
		driver.manage().window().maximize();
		
		//Xpath with single attributes
		driver.findElement(By.xpath("//input[@placeholder='Search']")).sendKeys("tshirts");
		
		//Xapth with multiple attribute
		//driver.findElement(By.xpath("//input[@name='search'][@placeholder='Search']")).sendKeys("T-shirts");
		
		//Xpath with and  operator
		//driver.findElement(By.xpath("//input[@name='search' and @placeholder='Search']")).sendKeys("T-shirts");

		//Xpath with or  operator
		//driver.findElement(By.xpath("//input[@name='search' or @placeholder='Search']")).sendKeys("T-shirts");
		
		//Xapth with inner text
//		driver.findElement(By.xpath("//a[text()='Macbook']")).click();
//		boolean displayStatus =  driver.findElement(By.xpath("//h3[text()='Featured']")).isDisplayed();
//	    String textValu =  driver.findElement(By.xpath("//h3[text()='Featured']")).getText();
//	    
	    //Xpath with containes method;
	    
	  //  driver.findElement(By.xpath("//input[contains(@placeholder, 'Searc')]")).sendKeys("true");
	   // driver.findElement(By.xpath("//input[starts-with(@placeholder, 'Searc')]")).sendKeys("true");
	    
	    //handling dynamic value with us available in runtime.
	    //[contains[@name,"st"]]
	    //[starts-with[@id, 'st']]
	    
	    // chained x-path
	    //div[@id="logo"]/a/img
	    
	  //  boolean imageStatus =  driver.findElement(By.xpath("//div[@id='logo']/a/img")).isDisplayed();
	    
	    
	    
	    
	    
	    
		  
	    
	
		
		
		
		
		
	}

}
