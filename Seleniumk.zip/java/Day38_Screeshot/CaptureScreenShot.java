package Day38_Screeshot;

import java.io.File;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CaptureScreenShot {
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		
		driver.get("https://demo.nopcommerce.com");
		//driver.manage().window().maximize();
		
		//single file upload
		//driver.findElement(By.xpath("//input[@id='filesToUpload']"));
		
		// take full page screen shot
//		TakesScreenshot ts = (TakesScreenshot) driver;
//		File sourceFile =  ts.getScreenshotAs(OutputType.FILE);
//		File targetfile = new File(System.getProperty("user.dir") +  "\\screenshot\\fullpage.png");
//		sourceFile.renameTo(targetfile);
		
		//2 capture scrreen shot of specific section
//	  WebElement featureProduct = 	driver.findElement(By.xpath("//div[@class='product-grid home-page-product-grid']"));
//	  File sourceFile =  featureProduct.getScreenshotAs(OutputType.FILE);
//	  File targetfile = new File(System.getProperty("user.dir") +  "\\screenshot\\featureProduct.png");
//	  sourceFile.renameTo(targetfile);
		
		//3 capture the screen shot of WebElement
		  WebElement logo  = 	driver.findElement(By.xpath("//img[@alt='nopCommerce demo store']"));
		  File sourceFile =  logo.getScreenshotAs(OutputType.FILE);
		  File targetfile = new File(System.getProperty("user.dir") +  "\\screenshot\\logo.png");
		  sourceFile.renameTo(targetfile);
	  
	}
}
