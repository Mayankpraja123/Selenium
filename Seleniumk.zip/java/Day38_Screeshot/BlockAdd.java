package Day38_Screeshot;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class BlockAdd {

	public static void main(String[] args) {

		ChromeOptions options = new ChromeOptions();
		File file = new File("Downloads\\uBlock-Origin-Chrome-Web-Store.crx");
		options.addExtensions(file);
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://text-compare.com/");
		

	}

}
