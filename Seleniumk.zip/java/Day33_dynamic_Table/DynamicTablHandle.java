package Day33_dynamic_Table;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DynamicTablHandle {

	private static final String Interger = null;

	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://www.demo.opencart.com/admin/index.php?route=common/login");
		int row =  driver.findElements(By.xpath("//table[@name='BookTable']//tr")).size();
		
	    WebElement username = driver.findElement(By.xpath("//input[@id='username']"));
	    //clear the input box
	    username.clear();
	    username.sendKeys("demo");
	    
	    WebElement password = driver.findElement(By.xpath("//input[@id='password']"));
	    //clear the input box clear.sendkey we can't do it return void
	    password.clear();
	    password.sendKeys("demo");
	    
	    driver.findElement(By.xpath("//button[normalize-space='Login']")).click();
	    //some time one pop cpme on screen and some time not so we nned to clise that pop up
	    
	   if( driver.findElement(By.xpath("//button[@class='btn-close']")).isDisplayed())
	   {
		   driver.findElement(By.xpath("//button[@class='btn-close']")).click();
	   }
	   
	   //click on customer
	    driver.findElement(By.xpath("//a[@class='parent collapsed'][normalize-space()='Customers']")).click();
	    driver.findElement(By.xpath("//ui[@id='collapse-S']//a[contains(text(),'Customers')]")).click();
	    
	    //S.substring(s.indexof("(")+1, s.indexof("Pages")-1) // returnt the exact number
	     String text =  driver.findElement(By.xpath("//div[contains(text(),'Pages')]")).getText();
	     
	     int total_page = Integer.parseInt(text.substring(text.indexOf("(")+1, text.indexOf("Pages")-1));
	     
	     //click looping ti repeating pages
	     
	     for(int p=1;p<total_page;p++)
	     {
	    	 if(p>1)
	    	 {
	    		WebElement active_page =  driver.findElement(By.xpath("//ul[@class='pagination']//*[text()="+p+"]"));
	    		active_page.click();
	    		Thread.sleep(3000);
	    	 }
	    	 
	    	 //reading the data 
	    	int row =  driver.findElement(By.xpath("//table[@class='table table-bordered table-hover']//tbody//tr")).size();\
	    	
	    	for(int i=0;i<row;i++)
	    	{
	    	String Customer_name = 	driver.findElement(By.xpath("//table[@class='table table-bordered table-hover']//tbody//tr["+i+"]//td[2]")).getText();
	    	String Email_Address = 	driver.findElement(By.xpath("//table[@class='table table-bordered table-hover']//tbody//tr["+i+"]//td[3]")).getText();
	    	
//	    	System.out.println("Customer_name" + Customer_name);
//	    	System.out.println("Email_Address" + Email_Address);
	    	
	    	System.out.println(Customer_name + "\t" + Email_Address + "\t" + Email_Address + "\t" );
	    	}
	    	
	    	
	     }
	     
	     
	    //same we try in testpractice 
	    
	    
	    
	    
	    
	    
	    

	}

}
