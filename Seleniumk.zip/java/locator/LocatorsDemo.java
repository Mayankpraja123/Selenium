package locator;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocatorsDemo {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		
		//driver.get("https://demo.nopcommerce.com/");
		//driver.get("https://demo.opencart.com/");
		driver.get("https://www.opencart.com/index.php?route=cms/demo");
		driver.manage().window().maximize();
		
		//name
		driver.findElement(By.name("search")).sendKeys("Mac");
		
		//id 
		boolean logoDisplayValue =  driver.findElement(By.id("logo")).isDisplayed();
		System.out.print(logoDisplayValue);
		
		//link text and partial link text
		driver.findElement(By.linkText("Tablets")).click();
		// in small portion of table but not used.
		driver.findElement(By.partialLinkText("Tab")).click();
		
		//className li calsssname taken.
		List<WebElement> headerLink =  driver.findElements(By.className("list-inline-item"));
		headerLink.size();
		
		// Tagname
		List<WebElement> Link =  driver.findElements(By.tagName("a"));
		
		List<WebElement> imgs =  driver.findElements(By.tagName("img"));
		
}

}
