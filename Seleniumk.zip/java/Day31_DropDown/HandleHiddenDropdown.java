package Day31_DropDown;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandleHiddenDropdown {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewEmployeeList");
		driver.manage().window().maximize();
		
		//Login 
		driver.findElement(By.name("username")).sendKeys("Admin");
		driver.findElement(By.name("password")).sendKeys("admin123");
		driver.findElement(By.xpath("//button[normalize-space()='Login']")).click();
		
		//Clicking on PIM
		driver.findElement(By.xpath("//a[@class='oxd-main-menu-item active']")).click();
		
		//CLICK ON DROPDOWN
		driver.findElement(By.xpath("(//i[@class='oxd-icon bi-caret-down-fill oxd-select-text--arrow'])[3]")).click();
		//driver.findElement(By.xpath("//span[normalize-space()='Automaton Tester']")).click();
		Thread.sleep(5000);
		
		//count number of options
		List<WebElement> ele = 	driver.findElements(By.xpath("//div[@role='listbox']//span"));
		System.out.println("element size :: " + ele.size());
		
		for(WebElement op : ele ) {
			System.out.println("Element :: " + op.getText());
		}
		

	}

}
