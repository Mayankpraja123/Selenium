package Day37_JavaScripEx;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FileUpload {

	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.get("https://davidwalsh.name/demo/multiple-file-upload.php");
		driver.manage().window().maximize();
		
		//single file upload
		driver.findElement(By.xpath("//input[@id='filesToUpload']")).sendKeys("location of files");
		// file uploading 
	   String fileName = 	driver.findElement(By.xpath("//ul[@id='fileList']//li")).getText();
	 
	   if(fileName.equals("fileName"))
	   {
		 System.out.println("file Upload");
	   }
	   else
	   {
		 System.out.print("Upload files");
	   }
		
	   
	   // for multiple file we con't use sendKeys method many times;;
	   //incorrect it will replacethe first files
	   //driver.findElement(By.xpath("//input[@id='filesToUpload']")).sendKeys("location of files");
	   //driver.findElement(By.xpath("//input[@id='filesToUpload']")).sendKeys("location of files");
		
	   String file1 = "store the path of first file";
	   String file2 = "store the path of second file";
	   
	   driver.findElement(By.xpath("//input[@id='filesToUpload']")).sendKeys(file1 + "\n" +  file2);
	   WebElement fileUploaded = driver.findElement(By.xpath("//ul[@id='fileList']//li"));
	   System.out.println("fileUploaded+::" + fileUploaded);
	   
	   // calculate the size 
	   
	   // Validatin of fiels
	   if(FileUpload==2)
	   {
		   System.out.println("All the file are uploaded");
	   }
	   else
	   {
		   
	   }
			   
			
	   // valie file name
	   if(driver.findElement(By.xpath("//ul[@id='fileList']//li[1]")).getText().equals("Fiels names") &&
			   driver.findElement(By.xpath("//ul[@id='fileList']//li[2]")).getText().equals("Fiels names")) {
		   System.out.println("Files anme matching");
	   }
	   
	   else {
		   System.out.println("Files anme matching not");
	   }
	

	}
}
