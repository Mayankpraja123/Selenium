package Day37_JavaScripEx;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ScrollPage {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		//driver.get("https://www.countries-ofthe-world.com/flags-of-the-world.html");
		driver.get("https://demo.nopcommerce.com");
		driver.manage().window().maximize();
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		 //1 Scroll down page by pixel number
        //js.executeScript("window.scrollBy(0,1500)","" );
       //System.out.println("window::" +js.executeScript("return window.pageYOffset;"));
      //		
 		
		//2 scroll the page till element is visible;
		//WebElement ele = driver.findElement(By.xpath("//strong[normalize-space()='Community poll']"));
		//js.executeScript("arguments[0].scrollIntoView();",ele);
		//System.out.println("window::" +js.executeScript("return window.pageYOffset;"));
		
		
		//3 entire whole page
		//js.executeScript("window.scrollBy(0,document.body.scrollHeight)","" );
		//System.out.println("window::" +js.executeScript("return window.pageYOffset;"));
		
		//go back Scrolling up to initail posiotn
		js.executeScript("window.scrollBy(0,-document.body.scrollHeight)","" );
		System.out.println("window::" +js.executeScript("return window.pageYOffset;"));
		
		
		
		
		
		
		
		
		
	}

}
