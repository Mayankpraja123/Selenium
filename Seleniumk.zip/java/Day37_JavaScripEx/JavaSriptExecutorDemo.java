package Day37_JavaScripEx;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class JavaSriptExecutorDemo {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().window().maximize();
		
		// some send key not work so we need to use javaEcxec;
		//driver.findElement(By.xpath("//input[@id='name']")).sendKeys("mayank");
		WebElement inputBox =  driver.findElement(By.xpath("//input[@id='name']"));
		
		//passing text into inputBox; alternate of sendkeys;
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("argument[0].setAttribute('value', 'John')", inputBox);
		
		//Clicking on the element;
		WebElement radio =  driver.findElement(By.xpath("//input[@id='male']"));
		js.executeScript("argument[0].click()", radio);
		
		
		
		
		
		
		
		
		
		
		

	}

}
