package Day32_Auto_suggest_dropDown;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Auto_suggest_dropDown {

	public static void main(String[] args) throws InterruptedException {
	
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		
		driver.findElement(By.name("q")).sendKeys("selenium");
		Thread.sleep(5000);
		
		List<WebElement>  optionList =driver.findElements(By.xpath("//ul[@role='listbox']//li//div[@role='option']"));
		
		System.out.println("optionList::"  + optionList.size());
		//bjs.com
		
		for(int i=0;i<optionList.size();i++)
		{
			System.out.println(optionList.get(i).getText());
			if(optionList.get(i).getText().equals("selenium"))
			{
				optionList.get(i).click();
			}
		}
		
		

	}

}
