package Day32_Auto_suggest_dropDown;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class StaticTable {

	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://testautomationpractice.blogspot.com/");
		int row =  driver.findElements(By.xpath("//table[@name='BookTable']//tr")).size();
		//driver.findElements(By.tagName("//tr"));//14 all the tr
		
		//find the colums
		int col = driver.findElements(By.xpath("//table[@name='BookTable']//tr[1]//th")).size();
		//String bookName = driver.findElement(By.xpath("//table[@name='BookTable']//tr[5]//td[1]")).getText();
	//	String bookName1 = driver.findElement(By.xpath("//table[@name='BookTable']//tr[7]//td[3]")).getText();
		
//		for(int i=2;i<row;i++)
//		{
//			for(int j=1;j<col;j++)
//			{
//				//System.out.println("Value ::"+ driver.findElement(By.xpath("//table[@name='BookTable']//tr["+i+"]//td["+j+"]")).getText());
//			}
//		}
//		
		
		for(int i=2;i<row;i++)
		{
			String name = driver.findElement(By.xpath("//table[@name='BookTable']//tr["+i+"]//td[1]")).getText();
			System.out.println("bookanen j::" + name);	
		}
		// nice assignment we need after completering this all sereos
		

	}

}
