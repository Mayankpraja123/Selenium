package Day32_Auto_suggest_dropDown;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebTables {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://testautomationpractice.blogspot.com/");
		int row =  driver.findElements(By.xpath("//table[@name='BookTable']//tr")).size();
		//List<WebElement> element =  driver.findElements(By.xpath("//table[@name='BookTable']//tr"));
		
		
		 
	}
}
