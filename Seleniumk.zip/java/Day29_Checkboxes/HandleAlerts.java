package Day29_Checkboxes;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandleAlerts {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/javascript_alerts");
		driver.manage().window().maximize();
		
		// 1) Normal alert with OK button
		
//		Thread.sleep(3000);
//		
//		driver.findElement(By.xpath("//button[@onclick='jsAlert()']")).click();
//		Thread.sleep(3000);
//		Alert	myalert =   driver.switchTo().alert();
//		System.out.print("get teat::" + myalert.getText() );
//		
		
		
		//2 confirm alert
		
	
//		driver.findElement(By.xpath("//button[@onclick='jsConfirm()']")).click();
//		Thread.sleep(3000);
//		
//		driver.switchTo().alert().accept();
//		driver.switchTo().alert().dismiss();
		
		// 3 //button[@onclick='jsPrompt()']
		
		driver.findElement(By.xpath("//button[@onclick='jsPrompt()']")).click();
		Thread.sleep(3000);
		
		Alert mypropt =   driver.switchTo().alert();
		mypropt.sendKeys("Welcomes");
		Thread.sleep(3000);
		System.out.println("" +mypropt.getText() );
		mypropt.accept();
		
		//WITHour swith command interview
		// using explicite wait
		
		
		
		
		
		
		
		
		
	}

}
