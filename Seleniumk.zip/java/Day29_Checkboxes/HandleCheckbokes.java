package Day29_Checkboxes;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandleCheckbokes {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().window().maximize();
		
		// 1)) Select 
		//driver.findElement(By.xpath("//input[@id='sunday']")).click();
		
		// 2) select all the checkboxs
		////input[@class='form-check-input' and @type='checkbox']
		
		List<WebElement> checkbox =   driver.findElements(By.xpath("//input[@class='form-check-input' and @type='checkbox']"));
		
//		for(int i=0;i<checkbox.size();i++)
//		{
//			checkbox.get(i).click();
//		}
		
//		for(WebElement checkboxs : checkbox)
//		{
//			checkboxs.click();
//		}
		
		
		//3 select last 3 checkbox
		
//		for(int i=4;i<checkbox.size();i++)
//		{
//			checkbox.get(i).click();
//			int b = checkbox.size() - 3;
//			if(b)
//			checkbox.get(i).click();
//		}
		
		for(WebElement check : checkbox)
		{
			check.click();
		}
		
		Thread.sleep(5000);
		
		for(int i=0;i<3;i++)
		{
			if(checkbox.get(i).isSelected())
			{
				checkbox.get(i).click();
			}
		}
		
		//alert
		
		
	}

}
