package Day36_Slider_action;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SliderActions {

	public static void main(String[] args) throws InterruptedException {
		
		 WebDriver driver = new ChromeDriver();
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		 driver.manage().window().maximize();
		 Actions act = new Actions(driver);
		
		 //min slider 
         driver.get("https://www.jqueryscript.net/demo/Price-Range-Slider-jQuery-UI/");
//	     WebElement min_slider = driver.findElement(By.xpath("//div[@class='price-range-block']//span[1]"));
//	     System.out.println("before moving  min_slider::"+min_slider.getLocation());
//	    
//	     act.dragAndDropBy(min_slider, 100,125).perform();
//	     System.out.println(" after moving min_slider::"+min_slider.getLocation());
		 
		 Thread.sleep(5000);
	     
	     //max slider 
	     WebElement max_slider = driver.findElement(By.xpath("//span[2]"));
	     System.out.println("max  moving  min_slider::"+ max_slider.getLocation());
	    
	     act.dragAndDropBy(max_slider,-100, 249).perform();
	     System.out.println(" after moving min_slider::"+max_slider.getLocation()); 
	     
	     
	     
	     
	     
	     
	     
	     
		
		
		
		

	}

}
