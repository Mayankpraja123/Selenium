package Day36_Slider_action;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class OpentheLinkInNewTab {

	public static void main(String[] args) {
		
		 WebDriver driver = new ChromeDriver();
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		 driver.manage().window().maximize();
         driver.get("https://demo.nopcommerce.com/");
         
         WebElement reglink =  driver.findElement(By.xpath("//a[normalize-space()='Register']"));
         //reglink.click(); // page opennin same page whchwe don't want
         
         Actions act = new Actions(driver);
         act.keyDown(Keys.CONTROL).click(reglink).keyUp(Keys.CONTROL).perform();
         
         ///switchto register pahe
         List<String> ids = new ArrayList(driver.getWindowHandles());
         driver.switchTo().window(ids.get(1));
         driver.findElement(By.xpath("//input[@id='FirstName']")).sendKeys("Mayank");
          
         driver.switchTo().window(ids.get(0));
         driver.findElement(By.xpath("//input[@id='small-searchterms']")).sendKeys("first page");
         
         
         
         
         
         
         
         
         
         
         
         
        
	}

}
