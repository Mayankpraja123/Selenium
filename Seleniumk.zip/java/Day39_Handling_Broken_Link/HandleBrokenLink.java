package Day39_Handling_Broken_Link;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandleBrokenLink {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		driver.get("https://www.deadlinkcity.com");

		
		//capture all the lnks
		List<WebElement> links =  driver.findElements(By.tagName("a"));
		System.out.print("Total number of links :: " + links);
		
		int numberofBrokenLink = 0;
		
		for(WebElement linkElement : links)
		{
			String hrefValue =  linkElement.getAttribute("href");
			
			if(hrefValue==null || hrefValue.isEmpty())
			{
				System.out.print("Href attributes value is null or empty.So Not possibble to check");
				continue;
			}
			//hit to the server;
			try
			{
				 URL url = new URL(hrefValue);// converted href value from string to url value;
			     HttpURLConnection conection = (HttpURLConnection) url.openConnection();
			     conection.connect();//
			     
			     if((conection.getResponseCode()>= 400)) {
			    	 System.out.print("Broken LINk");
			    	 numberofBrokenLink++;
			     }
			     else {
			    	 System.out.print("Not a  Broken LINk");
			     }	
			}
			catch (Exception e) {
			}	
		}
		System.out.println("numberofBrokenLink::" + numberofBrokenLink);
	}

}
