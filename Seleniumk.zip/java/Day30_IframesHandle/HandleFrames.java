package Day30_IframesHandle;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandleFrames {

	public static void main(String[] args) {
		//https://ui.vision/demo/webtest/frames/
		
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://ui.vision/demo/webtest/frames/");
		driver.manage().window().maximize();
		
		WebElement frame1 = driver.findElement(By.xpath("//frame[@src='frame_1.html']"));
		driver.switchTo().frame(frame1);
		// 4 methoda are available for sitch //id //name //webelemt pass frame //index 
		driver.findElement(By.xpath("//input[@name='mytext1']")).sendKeys("Hi");
		
		driver.switchTo().defaultContent();// driver come out to page again.
		
		//frame2
		
		WebElement frame2 = driver.findElement(By.xpath("//frame[@src='frame_2.html']"));
		driver.switchTo().frame(frame2);
		
		driver.findElement(By.xpath("//input[@name='mytext2']")).sendKeys("frame 2 enter");
		driver.switchTo().defaultContent();
		
		
		WebElement frame3 = driver.findElement(By.xpath("//frame[@src='frame_3.html']"));
		driver.switchTo().frame(frame3);
		driver.findElement(By.xpath("//input[@name='mytext3']")).sendKeys("Hi Frame 3");
		//driver.switchTo().defaultContent();
		
		// in the same we have only one ifram so 0 index using.
		driver.switchTo().frame(0);
		
		//open url in other page where you can get the xpath in other page easily.
		driver.findElement(By.xpath(""));
		
		//soemt time javascript exceuter use when click is not wokinf
		WebElement rbutton = driver.findElement(By.xpath(""));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("aguments[0].click()",rbutton);
		
		
		
		
	}
}
