package Day_26_get;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetMethods {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		//get the title of page;
		String value =  driver.getTitle();
		System.out.println(value);
		
		//getCurrent URls () return the url of string;
		//System.out.println(driver.getCurrentUrl());
		
		//PAGE SOURCE
		//System.out.print(driver.getPageSource()) ;
		
		// get window handle get singl browser window
//		String windowID = driver.getWindowHandle();
//		System.out.println("windowID"+ windowID);
		
		 Thread.sleep(10000);
		
		// open new browset
		 driver.findElement(By.linkText("OrangeHRM, Inc")).click();
		
		Set<String> multiID = driver.getWindowHandles();
		System.out.println("multiID+ " + multiID);
		
		
		
		
		
		
		
		

	}

}
