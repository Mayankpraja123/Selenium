package Day_26_get;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ConditionalMethods {

	public static void main(String[] args) {

		WebDriver driver = new ChromeDriver();

		driver.get("https://demo.nopcommerce.com/register");
		driver.manage().window().maximize();

		WebElement logo = driver.findElement(By.xpath("(//img[@alt='nopCommerce demo store'])[1]"));
		System.out.print(logo.isDisplayed());

		// isEnable
		boolean yes = driver.findElement(By.xpath("//input[@id='FirstName']")).isEnabled();
	}

}
